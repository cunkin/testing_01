/**
 * Rest layer error handling.
 */
package vn.com.pvcombank.web.rest.errors;
