/**
 * Repository layer.
 */
package vn.com.pvcombank.repository;
