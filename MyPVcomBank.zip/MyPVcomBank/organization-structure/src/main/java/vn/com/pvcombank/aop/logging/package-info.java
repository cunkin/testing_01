/**
 * Logging aspect.
 */
package vn.com.pvcombank.aop.logging;
