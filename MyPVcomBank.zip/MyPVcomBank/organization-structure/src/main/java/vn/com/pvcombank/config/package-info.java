/**
 * Application configuration.
 */
package vn.com.pvcombank.config;
