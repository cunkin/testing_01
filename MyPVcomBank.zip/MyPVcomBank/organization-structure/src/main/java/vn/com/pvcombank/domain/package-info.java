/**
 * Domain objects.
 */
package vn.com.pvcombank.domain;
