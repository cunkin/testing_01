/**
 * Rest layer.
 */
package vn.com.pvcombank.web.rest;
