/**
 * Data transfer objects for rest mapping.
 */
package vn.com.pvcombank.service.dto;
